//The configured options and settings for the tutorial.
//When cmake configures this header file the values 
//for @Tutorial_VERSION... will be replaced.
#define Tutorial_VERSION_MAJOR 2
#define Tutorial_VERSION_MINOR 6

//Library MathFunctions.
/* #undef USE_MYMATH */
