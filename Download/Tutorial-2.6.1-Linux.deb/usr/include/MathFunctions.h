/**
 * This is a basic cmake tutorial project.
 * It basically does nothing except for practice.
*/
float mysqrt(const float &number);